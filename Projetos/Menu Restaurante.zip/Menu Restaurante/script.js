//Função para Rolar a tela para a seção de Promoções
function scroll_promo() {
  window.scroll({
    top: 900,
    behavior: "smooth",
  });
}

//Função para Rolar a tela para a seção de Prato Feito
function scroll_prato_feito() {
  window.scroll({
    top: 1600,
    behavior: "smooth",
  });
}

//Função para Rolar a tela para a seção de Lanches

function scroll_lanches() {
  window.scroll({
    top: 2300,
    behavior: "smooth",
  });
}

//Função para Rolar a tela para a seção de Acompanhamentos

function scroll_acompanhamentos() {
  window.scroll({
    top: 3100,
    behavior: "smooth",
  });
}

//Função para Rolar a tela para a seção de Bebidas

function scroll_bebidas() {
  window.scroll({
    top: 3800,
    behavior: "smooth",
  });
}

/**
 * behavior: Determina se a rolagem é instantanea, ou animada suavemente
 */
